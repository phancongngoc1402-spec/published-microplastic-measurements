Operational materials

archived_codebook.json preserves the six original rows in 12_CODEBOOK!A2:G7.
operational_specification.txt and operational_specification.json provide the
expanded proposed instructions. These are development outputs, not an
authenticated historical rating protocol. No archived rating was modified.
decision_record_template.json is a blank reusable form.
controlled_examples.json contains four explicitly constructed demonstrations.
These examples are not environmental measurements or independent validation.
